package sw.c;

public class View extends FamilyAccount {
    public static void StartView() {
        System.out.println("______________家庭记账系统______________");
        System.out.println("              1.登录账号 ");
        System.out.println("              2.注册账号");
        System.out.print("请选择->");
    }

    public static void MenuView() {
        System.out.println("______________家庭记账系统______________");
        System.out.println("              1.登记收入 ");
        System.out.println("              2.登记支出");
        System.out.println("              3.查询账单");
        System.out.println("              4.退出账号");
        System.out.println("              5.结束运行");
        System.out.println("_______Home accounting system_______");
        System.out.print("请选择->");
    }
}
