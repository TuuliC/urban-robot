package sw.c;

public class FamilyAccount {
    Account account1 = new Account();
    static boolean isContinue = true;

    public static void main(String[] args) {//调用进行操作
        FamilyAccount familyAccount = new FamilyAccount();
        while (isContinue) {
            familyAccount.doMenu(familyAccount.StartMenu());
        }
    }

    public int StartMenu() {//初始菜单选择
        while (true) {
            View.StartView();
            char loginSelection = Utility.readLoginSelection();
            switch (loginSelection) {
                case '1'://登录
                    int i = account1.login();//返回登录对象在数组中的索引
                    if (i >= 0)
                        return i;
                    else
                        break;
                case '2'://注册
                    account1.errol();
            }
        }
    }

    public void doMenu(int i) {//主菜单操作
        while (true) {
            View.MenuView();
            char MenuSelection = Utility.readMenuSelection();
            switch (MenuSelection) {
                case '1'://登记收入
                    System.out.print("收入金额：");
                    double income = Utility.readNumber();
                    System.out.print("收入说明：");
                    String incomeExpl = Utility.readString();
                    System.out.println("收入已登记成功");
                    account1.account[i].balance += income;
                    account1.account[i].details += ++account1.account[i].count + "\t\t" + "收入\t\t\t" + income + "\t\t\t" +
                            account1.account[i].balance + "\t\t\t" + incomeExpl + "\n";
                    break;
                case '2'://登记支出
                    System.out.print("支出金额：");
                    double expend = Utility.readNumber();
                    System.out.print("支出说明：");
                    String expendExpl = Utility.readString();
                    System.out.println("支出已登记成功");
                    account1.account[i].balance -= expend;
                    account1.account[i].details += ++account1.account[i].count + "\t\t" + "支出\t\t\t" + expend + "\t\t\t" +
                            account1.account[i].balance + "\t\t\t" + expendExpl + "\n";
                    break;
                case '3'://查询账单
                    System.out.println("_______________收支明细_______________\n");
                    System.out.println(account1.account[i].details);
                    System.out.println();
                    System.out.println("________________已全部加载______________\n");
                    break;
                case '4'://退出账号
                    System.out.print("是否确定退出？（Y/N) ->");
                    char confirm = Utility.readConfirmSelection();
                    if (confirm == 'Y') {
                        System.out.println("已退出当前账号。");
                        return;
                    }
                    break;
                case '5'://退出运行
                    System.out.print("是否确定退出？（Y/N) ->");
                    char confirm1 = Utility.readConfirmSelection();
                    if (confirm1 == 'Y') {
                        System.out.println("已结束，感谢您使用本系统。");
                        isContinue = false;
                        return;
                    }
            }
        }
    }
}