package sw.c;

import java.util.Objects;

public class Account {
    String id;//账号
    String password;//密码
    int accountCount;//账号数量
    int balance;//账号金额
    int count = 0;//收入支出登记次数
    int loginCount = 0;//登录次数
    String details = "序号\t\t收支\t\t\t收支金额\t\t\t账户余额\t\t\t说明\n";
    Account[] account = new Account[100];

    public boolean setId(Account[] account) {//返回true表示取消，返回false表示成功
        System.out.print("请输入账号：");
        String newId = Utility.readAccountPassword();
        boolean isExit = judgeExit(newId);
        if (isExit) {//选择exit时退出
            return true;
        }
        int i = 0;
        if (accountCount == 0) {
            account[accountCount].id = newId;
            return false;
        } else if (accountCount >= 1) {
            for (; i < accountCount; i++) {//判断新账号是否已存在
                if (Objects.equals(newId, account[i].id)) {
                    System.out.println("账号已存在，请重新输入！");
                    setId(account);
                    break;
                }
            }
            if (i >= accountCount) {//新账号与已有账号均不同，则创建新账号
                account[accountCount].id = newId;
                return false;
            }
        }
        return true;
    }

    public boolean setPassword(Account[] account) {
        System.out.print("请输入密码：");
        String newPassword = Utility.readAccountPassword();
        boolean isExit = judgeExit(newPassword);
        if (isExit) {//选择exit时退出
            return true;
        }
        account[accountCount].password = newPassword;
        return false;
    }

    public void errol() {//注册账号
        account[accountCount] = new Account();
        System.out.println("____________注册账号（exit退出）____________");
        while (true) {//输入账号
            boolean isExit = setId(account);
            if (!isExit) {
                int lengthAccountNumber = account[accountCount].id.length();
                if (lengthAccountNumber < 6)
                    System.out.println("账号长度过短，请重新输入。");
                else break;
            } else return;
        }
        while (true) {//输入密码
            while (true) {//第一次输入密码
                boolean isExit = setPassword(account);
                if (!isExit) {
                    int lengthPassword = account[accountCount].password.length();
                    if (lengthPassword < 6) {
                        System.out.println("密码长度过短，请重新输入。");
                    } else if (Objects.equals(account[accountCount].id, account[accountCount].password)) {
                        System.out.println("账号不能与密码相同！请重新输入密码！");
                    } else break;
                } else return;
            }
            System.out.print("请再次输入密码：");//第二次输入密码
            String againPassword = Utility.readAccountPassword();
            boolean isExit = judgeExit(againPassword);
            if (!isExit) {
                if (Objects.equals(account[accountCount].password, againPassword)) {
                    System.out.println("注册成功！请牢记账号密码！\n");
                    accountCount++;//注册成功
                    break;
                } else
                    System.out.println("两次输入的密码不一致，请重新设置密码：");
            } else return;
        }
    }

    public int login() {//登录账号 返回负数代表取消登录，返回非负数代表登录成功，且返回的值为登录账号在数组中的索引
        while (true) {
            System.out.println("____________登录账号（exit退出）____________");
            System.out.print("请输入账号：");
            String inputId = Utility.readAccountPassword();
            if (Objects.equals(inputId, "exit"))
                return -1;
            System.out.print("请输入密码：");
            String inputPassword = Utility.readAccountPassword();
            if (Objects.equals(inputPassword, "exit"))
                return -1;
            if (accountCount == 0) {//如果没有注册过任何账号，则无论怎么输入都是密码错误
                System.out.println("账号密码错误！");
                continue;
            }
            for (int i = 0; i <= accountCount - 1; i++) {//判断账号密码是否正确
                if (inputId.equals(account[i].id) && inputPassword.equals(account[i].password)) {
                    System.out.print("登录成功。");
                    account[i].loginCount++;
                    if (account[i].loginCount == 1) {//初次登录，设置账户初始金额
                        System.out.print("\n请设置当前账户初始金额：");
                        account[i].balance = Utility.readNumber();
                        account[i].details += "  \t\t  \t\t\t" + account[i].balance + "\t\t\t\t" +
                                account[i].balance + "\t\t\t\t" + "初始金额\n";
                        System.out.println("设置成功，欢迎开始使用本系统。");
                    } else
                        System.out.println("欢迎回来！");
                    return i;//登录成功，返回账号在数组的索引
                }
            }
            System.out.println("账号密码错误，请重新输入！");
        }
    }

    public boolean judgeExit(String str) {//判断输入账号密码时选择exit退出
        return Objects.equals(str, "exit");
    }
}